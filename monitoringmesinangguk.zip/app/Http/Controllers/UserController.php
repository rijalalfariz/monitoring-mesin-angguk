<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function index()
    {
        return view('profile', [
            'pageTitle' => 'Profile'
        ]);
    }

    public function edit()
    {
        return view('editProfile');
    }

    public function update(Request $request)
    {
        $validatedData['username'] = $request['username'];
        $validatedData['password'] = bcrypt($request['password']);
        // ->validate([
        //     'username' => 'required|unique:users,username,',
        //     'password' => 'required|min:8'
        // ]);
        $path='';
        if($request->hasFile('image')){
            $filename = auth()->user()->id.'-'.$request->image->getClientOriginalName();
            $path = $request->file('image')->storeAs('images',$filename, 'public');
            $validatedData['image'] = $filename;
        }

        User::find(auth()->user()->id)
        ->update($validatedData);

        dd($path);
        // return redirect('/');
        // return redirect('/profile');
    }

    public function profile()
    {
        // dd('1');
        return view('profile', [
            'pageTitle' => 'Profile'
        ]);
    }
}
