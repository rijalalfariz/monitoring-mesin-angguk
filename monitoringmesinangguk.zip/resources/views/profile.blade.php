@extends('base')

@section('content')
<div class="d-flex">
    <x-sidebar>
    </x-sidebar>
    <div class="main-content flex-column">
        <x-navbar>
        </x-navbar>
        <div class="content">
            <form action="/edit-profile" method="post" class="" id="FormEditProfile" enctype="multipart/form-data">
                <div class="profile-card shadow-big mx-auto mt10v mb36 p64 d-flex">
                    <div id="ProfilePictureContainer" class="foto-profil-container bg-f0 mr36">
                        @if(Auth::user()->image)
                            <img class="image rounded-circle" src="{{asset('/storage/images/'.Auth::user()->image)}}" alt="profile_image" style="width: 80px;height: 80px; padding: 10px; margin: 0px; ">
                        @endif
                    </div>
                    <div class="profil-container div-grow d-flex flex-column">
                        @csrf
                        <div class="form-text-small mb18">Username</div>
                        <input class="mb36 form-input" type="text" placeholder="username" name="username" value="{{ Auth::user()->username }}" disabled>
                        <div class="form-text-small mb18">Password</div>
                        <input id="ProfilePictureInput" class="mb36 form-input" type="file" name="image" hidden>
                        <input class="mb36 form-input" type="password" placeholder="********" name="password" disabled>
                        <input class="mb36 form-input" type="password" placeholder="Old Password" name="old-password" hidden>

                        <div class="button-group justify-content-center d-flex BtnGroup">
                            <button class="btn fix bg-f0 shadow-big EditProfileBtn" type="button">Edit</button>
                            <button class="btn fix bg-ff shadow-big mr36 BatalEditProfileBtn" type="button" style="display: none">Batal</button>
                            <button class="btn fix bg-f0 shadow-big SimpanEditProfileBtn" type="submit" style="display: none">Simpan</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
</div>

<script>
    $('.EditProfileBtn').on('click', function(){
        $('#FormEditProfile input').prop('disabled', false)
        $('#FormEditProfile input[name="password"]').attr('placeholder', 'New Password')
        $('#FormEditProfile input[name="old-password"]').prop('hidden', false)
        $('#FormEditProfile .EditProfileBtn').hide();
        $('#FormEditProfile .BatalEditProfileBtn').show();
        $('#FormEditProfile .SimpanEditProfileBtn').show();
    })

    $('.BatalEditProfileBtn').on('click', function(){
        $('#FormEditProfile input').prop('disabled', true)
        $('#FormEditProfile input[name="password"]').attr('placeholder', '********')
        $('#FormEditProfile input[name="old-password"]').prop('hidden', true)
        $('#FormEditProfile .EditProfileBtn').show();
        $('#FormEditProfile .BatalEditProfileBtn').hide();
        $('#FormEditProfile .SimpanEditProfileBtn').hide();
    })

    $(function() {
        $('#profile').addClass('dragging').removeClass('dragging');
    });

    $('#ProfilePictureContainer').on('dragover', function() {
        $('#ProfilePictureContainer').addClass('dragging')
    }).on('dragleave', function() {
        $('#ProfilePictureContainer').removeClass('dragging')
    }).on('drop', function(e) {
        $('#ProfilePictureContainer').removeClass('dragging hasImage');

        if (e.originalEvent) {
            var file = e.originalEvent.dataTransfer.files[0];
            var reader = new FileReader();
            console.log(file);

            reader.readAsDataURL(file);
            reader.onload = function(e) {
                console.log(reader.result);
                $('#profile').css('background-image', 'url(' + reader.result + ')').addClass('hasImage');
                $('#ProfilePictureInput').files[0] = file;
            }
        }
    });

    $('#ProfilePictureContainer').on('click', function(e) {
        console.log('clicked')
        $('#ProfilePictureInput').click();
    });
    window.addEventListener("dragover", function(e) {
        e = e || event;
        e.preventDefault();
    }, false);
    window.addEventListener("drop", function(e) {
        e = e || event;
        e.preventDefault();
    }, false);
    $('#ProfilePictureInput').change(function(e) {

        var input = e.target;
        if (input.files && input.files[0]) {
            var file = input.files[0];
            var reader = new FileReader();

            reader.readAsDataURL(file);
            reader.onload = function(e) {
                console.log(reader.result);
                $('#ProfilePictureContainer').css('background-image', 'url(' + reader.result + ')').addClass('hasImage');
            }
        }
    })

</script>

@endsection