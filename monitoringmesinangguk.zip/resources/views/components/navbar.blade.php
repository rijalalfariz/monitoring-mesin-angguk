<div class="navbar">
    <div class="page-now">Monitoring Mesin Angguk</div>
    <div class="user-group">
        <div class="user-image">

        </div>
        <div class="user-name">
            {{ Auth::user()->username }}
        </div>
    </div>
</div>
