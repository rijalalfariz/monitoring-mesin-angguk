

<?php $__env->startSection('content'); ?>
<div class="d-flex">
    <?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>
    <div class="main-content flex-column">
        <?php if (isset($component)) { $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Navbar::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c)): ?>
<?php $component = $__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c; ?>
<?php unset($__componentOriginal08d9d46900ea68d5dc06d8728734a2fd47ca153c); ?>
<?php endif; ?>
        <div class="content">
            <form action="/edit-profile" method="post" class="" id="FormEditProfile" enctype="multipart/form-data">
                <div class="profile-card shadow-big mx-auto mt10v mb36 p64 d-flex">
                    <div class="foto-profil-container bg-f0 mr36">
                        <?php if(Auth::user()->image): ?>
                            <img class="image rounded-circle" src="<?php echo e(asset('/storage/images/'.Auth::user()->image)); ?>" alt="profile_image" style="width: 80px;height: 80px; padding: 10px; margin: 0px; ">
                        <?php endif; ?>
                    </div>
                    <div class="profil-container div-grow d-flex flex-column">
                        <?php echo csrf_field(); ?>
                        <div class="form-text-small mb18">Username</div>
                        <input class="mb36 form-input" type="text" placeholder="username" name="username" value="<?php echo e(Auth::user()->username); ?>" disabled>
                        <div class="form-text-small mb18">Password</div>
                        <input class="mb36 form-input" type="file" name="image" disabled>
                        <input class="mb36 form-input" type="password" placeholder="********" name="password" disabled>
                        <input class="mb36 form-input" type="password" placeholder="Old Password" name="old-password" hidden>

                        <div class="button-group justify-content-center d-flex BtnGroup">
                            <button class="btn fix bg-f0 shadow-big EditProfileBtn" type="button">Edit</button>
                            <button class="btn fix bg-ff shadow-big mr36 BatalEditProfileBtn" type="button" style="display: none">Batal</button>
                            <button class="btn fix bg-f0 shadow-big SimpanEditProfileBtn" type="submit" style="display: none">Simpan</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
</div>

<script>
    $('.EditProfileBtn').on('click', function(){
        $('#FormEditProfile input').prop('disabled', false)
        $('#FormEditProfile input[name="password"]').attr('placeholder', 'New Password')
        $('#FormEditProfile input[name="old-password"]').prop('hidden', false)
        $('#FormEditProfile .EditProfileBtn').hide();
        $('#FormEditProfile .BatalEditProfileBtn').show();
        $('#FormEditProfile .SimpanEditProfileBtn').show();
    })

    $('.BatalEditProfileBtn').on('click', function(){
        $('#FormEditProfile input').prop('disabled', true)
        $('#FormEditProfile input[name="password"]').attr('placeholder', '********')
        $('#FormEditProfile input[name="old-password"]').prop('hidden', true)
        $('#FormEditProfile .EditProfileBtn').show();
        $('#FormEditProfile .BatalEditProfileBtn').hide();
        $('#FormEditProfile .SimpanEditProfileBtn').hide();
    })

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\B_Jobs\Projekan\MonitoringMesinAngguk\monitoring-mesin-angguk\resources\views/profile.blade.php ENDPATH**/ ?>