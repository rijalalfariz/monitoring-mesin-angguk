<div class="navbar">
    <div class="page-now">Monitoring Mesin Angguk</div>
    <div class="user-group">
        <div class="user-image">

        </div>
        <div class="user-name">
            <?php echo e(Auth::user()->username); ?>

        </div>
    </div>
</div>
<?php /**PATH D:\B_Jobs\Projekan\MonitoringMesinAngguk\monitoring-mesin-angguk\resources\views/components/navbar.blade.php ENDPATH**/ ?>